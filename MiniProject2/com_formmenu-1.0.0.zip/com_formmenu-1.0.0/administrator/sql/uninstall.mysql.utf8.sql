DROP TABLE IF EXISTS `#__formmenu_recordlist`;
